// cc OldMaxTemperature Application to find the maximum temperature, using the old MapReduce API
import java.io.IOException;
import java.util.Iterator;

import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.*;
import org.apache.hadoop.mapred.*;
import java.util.*;
import java.util.ArrayList;
import java.util.List;

// vv OldMaxTemperature
public class Fill {

  public static List header = new ArrayList();
  
  static class FillMapper /*[*/extends MapReduceBase/*]*/
    /*[*/implements Mapper/*]*/<LongWritable, Text, Text, Text> {
     
   
    
    @Override
    public void map(LongWritable key, Text value,
        /*[*/OutputCollector<Text, Text> output, Reporter reporter/*]*/)
        throws IOException {
	
			TreeMap<Integer, String> treeMap = new TreeMap<Integer, String>();
			
      String cadena = value.toString();
			String[] linea = cadena.split(":");
			String[] anioValor = linea[1].split(",");
		  String[] valor = new String[2];
      for(int i=0; i<anioValor.length; i++){
						valor = anioValor[i].split("@");
						treeMap.put(Integer.parseInt(valor[0]), valor[1]);
			}
    

			for (Map.Entry<Integer,String> entry : treeMap.entrySet() ){
					if(!header.contains(entry.getKey())){
							header.add(entry.getKey());
					}
		 	}

      Collections.sort(header);
      String print = "";
      for(int j=0; j<header.size(); j++){
				if(treeMap.containsKey(header.get(j))){
					print += header.get(j)+"@"+treeMap.get(header.get(j))+",";
				}
				else{
					print += header.get(j)+"@0,";
				}
			}
      

		 	output.collect( new Text(header.size()*(-1) + ":" +linea[0] ), new Text( print ) );
	
    }
  }
  
  static class FillReducer /*[*/extends MapReduceBase/*]*/
    /*[*/implements Reducer/*]*/<Text, Text, Text, Text> {
    int count = 0;
	ArrayList header = new ArrayList();
    @Override
    public void reduce(Text key, /*[*/Iterator/*]*/<Text> values,
        /*[*/OutputCollector<Text, Text> output, Reporter reporter/*]*/)
        throws IOException {
		String s_key = key.toString();
		String s_values =values.next().toString();
		
		String[] numanios_ocupacion = s_key.split(":");
		String ocupacion = numanios_ocupacion[1];
		
		String[] anio_people = s_values.split(",");
		
		TreeMap<Integer, String> treeAnioPeople = new TreeMap<Integer, String>();	
		
		if( count == 0){
			
			for( String ap: anio_people){
				String[] a_p = ap.split("@");
				header.add( Integer.parseInt( a_p[0] ) );
			}
			count++;
			
			String cadenaHeader = "";
			for(int k=0; k<header.size(); k++){
				cadenaHeader += header.get(k)+"\t";
			}
			
			output.collect( new Text("Occupation"), new Text(cadenaHeader+"\tMAXYEAR") );
		}
		
		//llenamos el tree map
		for(int i=0; i<anio_people .length; i++){
			String[] valor = anio_people[i].split("@");
			treeAnioPeople.put(Integer.parseInt(valor[0]), valor[1].trim());
		}
		
		//Creamos la línea para el output
		String print = "";
		int mayor = 0;
		int people = 0;
		String anio_con_mayor = ""; //Año con mayor people
		for(int j=0; j<header.size(); j++){
			if(treeAnioPeople.containsKey(header.get(j))){
				people = Integer.parseInt(treeAnioPeople.get(header.get(j)));
				print += people +"\t";
				if(people > mayor){
					mayor = people;
					anio_con_mayor = header.get(j).toString();
				}
			}
			else{
				print += "0     \t";
			}
		}
		
		//Calculamos el año que tuvo más people
		
		output.collect( new Text( ocupacion ), new Text(print+"\t"+anio_con_mayor) );	
		
		
			
		
		/*
		
	   
		TreeMap<Integer, String> treeMap = new TreeMap<Integer, String>();	
	   
	   
	   
	   
			//Collections.sort(header);
	    String cadena = "";
			String[] anioValor;

			output.collect( key, new Text(values.next()) );	

      
			while (values.hasNext()) {
        	cadena = values.next()+"";
					anioValor = cadena.split(",");
           for(int i=0; i<anioValor.length; i++){
						String[] valor = anioValor[i].split("@");
						treeMap.put(Integer.parseInt(valor[0]), valor[1].trim());
					}
      	}

      String print = "";
      for(int j=0; j<header.size(); j++){
				if(treeMap.containsKey(header.get(j))){
					print += treeMap.get(header.get(j))+"\t";
				}
				else{
					print += "0\t";
				}
			}
      
      if (count == 0){
        String cadenaHeader = "";
        for(int k=0; k<header.size(); k++){
				   cadenaHeader += header.get(k)+"\t";
				}
				output.collect( new Text("Occupation"), new Text(header.toString()) );
        count++;
      }
      

			//output.collect( key, new Text(print) );	
		*/
    }
  }

  
}
// ^^ OldMaxTemperature
